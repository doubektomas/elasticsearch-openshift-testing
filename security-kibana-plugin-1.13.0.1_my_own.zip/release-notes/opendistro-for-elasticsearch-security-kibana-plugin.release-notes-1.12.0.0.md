## Version 1.12.0.0

### Maintenance
* Add support for elasticsearch 7.10.0 ([#626](https://github.com/opendistro-for-elasticsearch/security-kibana-plugin/pull/626))

